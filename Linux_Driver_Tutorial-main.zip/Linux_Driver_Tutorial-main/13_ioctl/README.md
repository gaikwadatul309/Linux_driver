To run this example create a device file with:

~~~~~
sudo mknod /dev/dummy c 64 0
~~~~~

