# Serial (UART) Driver

For this driver you need an UART-to-USB Adpter to receive and send characters to the Linux Driver.

Run `sudo raspi-config`, go to *Interfaces* -> *Serial* and Disable *Login Shell over SSH* but enable *Serial Port*.


